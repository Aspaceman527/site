# Cookie Clicker
Cookie Clicker is an incremental game created by French programmer Julien "Orteil" Thiennot in 2013. The user initially clicks on a big cookie on the screen, earning a single cookie per click. They can then spend their earned cookies upon purchasing assets such as "cursors" and other "buildings" that automatically produce cookies. Upgrades are also available and can improve the efficiency of clicks and buildings, among many other mechanics that allow the user to earn cookies in different ways. Though the game has no ending, it has hundreds of achievements, and users may aim to reach milestone numbers of cookies.
<br>
The game is one of the first and most important in the genre of incremental games and has a dedicated fanbase. Though the first version was coded in one night, Cookie Clicker is regularly updated. It has been widely described as addictive, and it has been noted that the game almost does not require a human to play it.
<br>
2.021 source code for... educational purposes... BETA edition! <br>
Download and Extract to delete free time.. BETA EDITION! Or just use the website. <br> <br>
Do not worry, I will be updating this to be up to date with the current Cookie Clicker beta version. <br>
<!-- Well guess what, 2.021 came out... what happened to 2.020??  -->
Credits obviously go Orteil, visit the official website here: http://orteil.dashnet.org/cookieclicker/
