Why are you here nerd?
